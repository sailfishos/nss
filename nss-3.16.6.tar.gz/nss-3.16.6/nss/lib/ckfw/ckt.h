/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/* get back to just one set of PKCS #11 headers. Use the onese that
 * are easiest to maintain from the RSA website */
/* this one is the one that defines NSS specific data */
#include "pkcs11n.h"
